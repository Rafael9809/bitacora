package mx.com.vepormas.service;

import mx.com.vepormas.vo.BitacoraInput;
import mx.com.vepormas.vo.HeaderRequest;

public interface Bitacorizacion {
	
	Boolean saveBitacora(BitacoraInput bi, HeaderRequest req) throws Exception;

}
