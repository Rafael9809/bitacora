package mx.com.vepormas.vo;

public class HeaderRequest {
	
	private String ip;
	private String agente;
	
	public String getIp() {
		return ip;
	}
	
	public void setIp(String ip) {
		this.ip = ip;
	}

    public String getAgente() {
        return agente;
    }

    public void setAgente(String agente) {
        this.agente = agente;
    }
	
}

