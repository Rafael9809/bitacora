package mx.com.vepormas.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import mx.com.vepormas.codi.conn.mongo.repository.dcto.BitacoraDcto;

@Repository
public interface BitacoraRepository extends MongoRepository<BitacoraDcto, Long> {
    
}