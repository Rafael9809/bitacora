package mx.com.vepormas.vo;

import java.util.Date;

public class ResponseVO<T> {
	
	
	public static final int EXITO = 200;
	public static final int SIN_RESULTADO = 204;
	public static final int ERROR_DATOS = 404;
	public static final int NEGOCIO = 409;
	public static final int ERROR = 500;
	
	private Integer code;
	private Boolean status;
	private String message;
	private Date dateTime;
	private T data;
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	
}
