package mx.com.vepormas.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.vepormas.codi.conn.mongo.repository.dcto.BitacoraDcto;
import mx.com.vepormas.repository.BitacoraRepository;
import mx.com.vepormas.service.Bitacorizacion;
import mx.com.vepormas.vo.BitacoraInput;
import mx.com.vepormas.vo.HeaderRequest;

@Service
public class BitacorizacionImpl implements Bitacorizacion{

	@Autowired
	BitacoraRepository br;
	
	@Override
	public Boolean saveBitacora(BitacoraInput bi, HeaderRequest req) throws Exception{
		br.save(input2Mongo(bi, req));
		return true;
	}

	private BitacoraDcto input2Mongo(BitacoraInput bi, HeaderRequest req)
	{
		return new BitacoraDcto(bi.getCanal(),req.getAgente(),req.getIp(),bi.getUsuario(),bi.getOperacion(),bi.getFechaEvento(),bi.getRequest(),bi.getResponse(),bi.getException());
	}

}
