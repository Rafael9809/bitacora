package mx.com.vepormas.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import mx.com.vepormas.service.Bitacorizacion;
import mx.com.vepormas.vo.*;

@RestController
@RequestMapping(path = "/bitacora/wallet")
public class BitacoraController {
	
	@Autowired
	Bitacorizacion bi;

	HeaderRequest disp;
	
	@PostMapping("/send")
    public ResponseEntity<ResponseVO<Boolean>> getCodigo(
			@Valid @RequestBody BitacoraInput request, HttpServletRequest hreq) {
		ResponseVO<Boolean> response = new ResponseVO<>();
		
		Boolean resp = null;
		disp = new HeaderRequest();
		try{
			disp.setAgente( hreq.getHeader("User-Agent"));
			disp.setIp( getClientIp( hreq ) );

			resp = bi.saveBitacora(request, disp);
		}
		catch(Exception e) {
			response.setStatus(false);
			response.setDateTime(new Date());
			response.setMessage("Error al almacenar en bitacora");
			response.setCode(500);
			return ResponseEntity.ok().body(response);
		}
		response.setStatus(resp);
		response.setDateTime(new Date());
		response.setMessage("Operacion almacenada en bitacora");
		response.setCode(200);
		return ResponseEntity.ok().body(response);
    }

	private String getClientIp(HttpServletRequest request) {
		String remoteAddr = "";
		if (request != null) {
			remoteAddr = request.getHeader("X-FORWARDED-FOR");
			if (remoteAddr == null || "".equals(remoteAddr)) {
				remoteAddr = request.getRemoteAddr();
			}			
		}		
		return remoteAddr.split(",")[0];
		
	}
}
