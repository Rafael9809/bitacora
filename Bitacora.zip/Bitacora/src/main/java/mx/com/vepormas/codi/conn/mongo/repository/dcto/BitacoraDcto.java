package mx.com.vepormas.codi.conn.mongo.repository.dcto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document( collection = "BitacoraDcto" )
public class BitacoraDcto {
	
	private int canal;
	private String agente;
	private String ip;
	private String usuario;
	private String operacion;
	private String fecha;
	private String request;
	private String response;
	private String exception;
	
	public BitacoraDcto() {super();}
	
	public BitacoraDcto(int canal, String agente, String ip, String usuario, String operacion,
			String fecha, String request, String response, String exception) {
		super();
		this.canal = canal;
		this.agente = agente;
		this.ip = ip;
		this.usuario = usuario;
		this.operacion = operacion;
		this.fecha = fecha;
		this.request = request;
		this.response = response;
		this.exception = exception;
	}
	
	public int getCanal() {
		return canal;
	}
	public void setCanal(int canal) {
		this.canal = canal;
	}
	public String getAgente() {
		return agente;
	}
	public void setAgente(String agente) {
		this.agente = agente;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getOperacion() {
		return operacion;
	}
	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getException() {
		return exception;
	}
	public void setException(String exception) {
		this.exception = exception;
	}
	
}