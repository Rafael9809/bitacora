package mx.com.vepormas.vo;

import javax.validation.Valid;

public class RequestVO<T> {
	
	@Valid
	private T data;

	public T getData() {
		return data;
	}

}
